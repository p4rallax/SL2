#include<stdio.h>

int main(int argc, char *argv[])
{
	int a,b,c;
	
	a=atoi(argv[1]);
	b=atoi(argv[2]);
	c=atoi(argv[3]);
	
	    if (a > b && a > c)             
            printf("%d is largest", a);
 	   
        else if (b > c && b > a) 
            printf ("%d is largest", b);
 
		else if (c > a && c > b) 
            printf("%d is largest ",c);
	
	
	return 0;
	
}
