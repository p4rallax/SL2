#include<stdio.h>
#include<stdlib.h>
#include<wait.h>
#include<unistd.h>
int main()
{
int retval;
 int fid=fork();
 if(fid==0)
 {
   execl("/home/admin123/large", "large" , "12" ,"5" , "2", NULL);
   exit(100);
  }
  if(fid>0)
  {
   wait(&retval);
   printf("\n exit status of child %d ", WEXITSTATUS(retval));
  }
  return 0;
 }
