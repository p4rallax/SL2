#include<stdio.h>
#include<stdlib.h>
#include<wait.h>
#include<unistd.h>

int main()
{ 
	int x=25;
	int y=10;
	int z;
	int fid=fork();
	if(fid==0)
	{
	  printf("\n This is child process,Process is %d, child is %d \n", getpid(), getppid());
	  z=x+y;
	  printf("\n Addition is x and y is %d" ,z);
	  exit(100);
	}
	if(fid>0)
	{
	  printf("\n This is parent process  %d ",getpid());
	  z=x-y;
	  printf("\nSubtraction of number is %d \n", z);
	  sleep(3);
	}
 return 0;
}  
	   
