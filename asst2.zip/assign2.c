#include<stdio.h>
#include<stdlib.h>
#include<wait.h>
#include<unistd.h>
int main()
{ 
	int fid=fork();
	if(fid==0)
	{
	  	printf("This is child process. Process id %d , Process id of child process is %d \n", getpid(), getppid() );
	  	sleep(3);
	  	printf("Orphan State");
	  	printf("\n This is child process, process is %d , parent is %d \n" ,getpid(),getppid());
	}
	if(fid>0)
	{
		printf("I am parent process, process is %d\n", getppid());
		//printf("Child is going into zombie state \n ");
		 
		exit(0);
		//system("ps");
	} 	
	return 0;
}
